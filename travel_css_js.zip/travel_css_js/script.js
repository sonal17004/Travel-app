// wishlist.js
document.addEventListener("DOMContentLoaded", () => {
  /* ----------  ADD TO WISHLIST  ---------- */
  const wishlistBtns = document.querySelectorAll(".wishlist-btn");

  wishlistBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const { title, country, image } = btn.dataset;

      // read or create array in localStorage
      const wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

      // avoid duplicates
      if (wishlist.some(item => item.title === title)) {
        alert("Already in wishlist!");
        return;
      }

      wishlist.push({ title, country, image });
      localStorage.setItem("wishlist", JSON.stringify(wishlist));
      alert("Added to wishlist!");
    });
  });

  /* ----------  SHOW WISHLIST PAGE  ---------- */
  const wishlistContainer = document.getElementById("wishlist");
  if (wishlistContainer) {
    const wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

    if (wishlist.length === 0) {
      wishlistContainer.insertAdjacentHTML(
        "beforeend",
        "<p>Your wishlist is empty.</p>"
      );
      return;
    }

    wishlist.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "wishlist-item";
      card.innerHTML = `
        <img src="${item.image}" alt="${item.title}" />
        <div class="info">
          <h4>${item.title}</h4>
          <p>${item.country}</p>
          <button class="remove-btn" data-index="${index}">Remove</button>
        </div>
      `;
      wishlistContainer.appendChild(card);
    });

    // remove buttons
    wishlistContainer.addEventListener("click", e => {
      if (!e.target.matches(".remove-btn")) return;

      const index = e.target.dataset.index;
      wishlist.splice(index, 1);
      localStorage.setItem("wishlist", JSON.stringify(wishlist));
      // quick re‑render
      location.reload();
    });
  }
});
