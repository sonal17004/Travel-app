// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCLXMtlmSjjUyPqGPl67nQ-D6SZHVzhsaI",
  authDomain: "my-travel-app-8df4e.firebaseapp.com",
  projectId: "my-travel-app-8df4e",
  storageBucket: "my-travel-app-8df4e.firebasestorage.app",
  messagingSenderId: "883756429136",
  appId: "1:883756429136:web:4b813e1d42ee6db4adc655",
  measurementId: "G-3X2MMQ760C"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);