// Target the wishlist container
const wishlistContainer = document.getElementById('wishlist-items');

// Get the wishlist from localStorage or set it to an empty array
const wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

// Render all wishlist items on the page
function renderWishlist() {
  wishlistContainer.innerHTML = '';

  if (wishlist.length === 0) {
    wishlistContainer.innerHTML = '<p class="empty">Your wishlist is empty 💔</p>';
    return;
  }

  wishlist.forEach((item, index) => {
    const div = document.createElement('div');
    div.className = 'destination-card';

    div.innerHTML = `
      <img src="${item.image}" alt="${item.title}" />
      <div class="destination-info">
        <h3>${item.title}</h3>
        <p>${item.description}</p>
        <div class="rating-remove">
          <span>⭐ ${item.rating}</span>
          <button onclick="removeItem(${index})">Remove</button>
        </div>
      </div>
    `;

    wishlistContainer.appendChild(div);
  });
}

// Remove a single item by index
function removeItem(index) {
  wishlist.splice(index, 1);
  localStorage.setItem('wishlist', JSON.stringify(wishlist));
  renderWishlist();
}

// Initial render
renderWishlist();
