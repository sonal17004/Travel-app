// ✅ Replace these values with your actual Firebase config:
const firebaseConfig = {
  apiKey: "AIzaSyCLXMtlmSjjUyPqGPl67nQ-D6SZHVzhsaI",
  authDomain: "my-travel-app-8df4e.firebaseapp.com",
  projectId: "my-travel-app-8df4e",
  storageBucket: "my-travel-app-8df4e.firebasestorage.app",
  messagingSenderId: "883756429136",
  appId: "1:883756429136:web:4b813e1d42ee6db4adc655",
  measurementId: "G-3X2MMQ760C"
};

// ✅ Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// 🔐 Handle Sign Up
const signupForm = document.getElementById("signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value.trim();

    if (!name || !email || !password) {
      alert("Please fill in all fields!");
      return;
    }

    auth.createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        return userCredential.user.updateProfile({ displayName: name });
      })
      .then(() => {
        window.location.href = "index.html";
      })
      .catch((error) => {
        alert("Signup Failed: " + error.message);
      });
  });
}

// 🔐 Handle Login
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

    if (!email || !password) {
      alert("Please enter email and password");
      return;
    }

    auth.signInWithEmailAndPassword(email, password)
      .then(() => {
        window.location.href = "index.html";
      })
      .catch((error) => {
        alert("Login Failed: " + error.message);
      });
  });
}
